#!/usr/bin/env bash

if [ "$#" -ne 1 ]; then
	echo "Unxpected: missing channel_id"
	echo ""
	echo "  some options:"
	echo ""
	echo "  310 : CME Globex Equity Futures"
	echo "  311 : CME Globex Equity Options"
	echo "  312 : CME Globex Interest Rate Futures"
	echo "  313 : CME Globex Interest Rate Options"
	echo "  314 : CME Globex FX Futures"
	echo "  315 : CME Globex FX Options"
	echo "  316 : CME Globex Commodity Futures"
	echo "  317 : CME Globex Commodity Options"
	echo "  326 : CME Crypto Futures"
	echo "  327 : CME Crypto Options"
	echo "  380 : NYMEX Globex Emissions Futures"
	echo "  381 : NYMEX Globex Emissions Options"
	echo "  382 : NYMEX Globex Crude &amp; Crude Refined Futures"
	echo "  383 : NYMEX Globex Crude &amp; Crude Refined Options"
	echo "  384 : NYMEX Globex Metals, Softs, &amp; Alternative Market Futures"
	echo "  385 : NYMEX Globex Metals, Softs, &amp; Alternative Market Options"
	echo "  386 : NYMEX Globex Nat Gas &amp; other Non-Crude Energy Futures"
	echo "  387 : NYMEX Globex Nat Gas &amp; other Non-Crude Energy Options"
	echo ""
	exit 1
fi

# note!
# must be started with onload

ONLOAD="$(which onload)"

$ONLOAD $HOME/opt/conda/bin/roq-cme \
	--flagfile $HOME/etc/cme/flags.cfg \
	--config_file $HOME/etc/cme/config.toml \
	--client_listen_address $HOME/run/cme \
	--event_log_symlink true \
	--auth_keys_file $HOME/etc/cme/keys.json \
	--multicast_config_file $HOME/etc/cme/config.xml \
	--multicast_channel_ids $1 \
	--cache_all_reference_data true \
	$@
